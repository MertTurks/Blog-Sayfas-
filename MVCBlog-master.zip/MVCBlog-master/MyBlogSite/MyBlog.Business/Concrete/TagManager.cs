﻿using MyBlog.Business.Abstract;
using System;
using System.Collections.Generic;
using System.Text;

namespace MyBlog.Business.Concrete
{
   public class TagManager : ITagManager
    {
    }
}
