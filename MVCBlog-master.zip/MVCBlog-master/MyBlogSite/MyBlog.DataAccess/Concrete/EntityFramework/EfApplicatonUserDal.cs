﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MyBlog.DataAccess.Concrete.EntityFramework
{
   public class EfApplicatonUserDal
    {
    }
}
