﻿using MyBlog.Entities.Concrete;
using System;
using System.Collections.Generic;
using System.Text;

namespace MyBlog.DataAccess.ViewModels
{
    public class CategoriesViewModel
    {
        public List<Category>   Categories { get; set; }
    }
}
