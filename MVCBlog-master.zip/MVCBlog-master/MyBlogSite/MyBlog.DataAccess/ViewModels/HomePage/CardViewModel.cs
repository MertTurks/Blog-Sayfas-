﻿using MyBlog.Entities.Concrete;
using System;
using System.Collections.Generic;
using System.Text;

namespace MyBlog.DataAccess.ViewModels.HomePage
{
    public class CardViewModel
    {
        public List<Category> Categories { get; set; }

    }
}
