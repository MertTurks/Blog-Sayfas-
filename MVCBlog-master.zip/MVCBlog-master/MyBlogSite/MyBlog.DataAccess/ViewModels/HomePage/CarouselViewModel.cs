﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MyBlog.DataAccess.ViewModels.HomePage
{
    public class CarouselViewModel
    {
    }
}
