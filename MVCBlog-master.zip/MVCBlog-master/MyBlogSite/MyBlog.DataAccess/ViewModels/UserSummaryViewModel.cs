﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MyBlog.DataAccess.ViewModels
{
    public class UserSummaryViewModel
    {
        public string FullName { get; set; }

    }
}
