﻿using MyBlog.Entities.DTOs;
using System;
using System.Collections.Generic;
using System.Text;

namespace MyBlog.DataAccess.ViewModels
{
    public class RegisterViewModel
    {
        public UserDto UserInfo { get; set; }
    }
}
